

<?php $__env->startSection('title','Customers'); ?>

<?php $__env->startSection('content'); ?>
<main>
    <div class="container-fluid px-4">
       <div class="row">
         <div class="col fw-bold fs-3 text-dark">
           Customers
           <hr class="dropdown-divider" style="height:3px;">
         </div>
       </div>
       <div class="row">
         <div class="card">
           <div class="card-header">
            <div class="d-grid gap-2 d-md-block float-end">
              <a href="" class="btn btn-primary "><i class="bi bi-printer"></i> Print</a>
            </div>
            </div>
           <div class="card-body">
            <table id="datatable" class="table table-bordered">
               <thead>
                 <tr>
                  <th>Name</th>
                  <th>Phone</th>
                  <th>Address</th>
                  <th>Action</th>
                 </tr>
               </thead>
               <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                   <td><?php echo e($order->name); ?></td>
                   <td><?php echo e($order->phone_number); ?></td>
                   <td><?php echo e($order->address); ?></td>
                   <td>
                    <a name="edit" href="" data-bs-toggle="modal" data-bs-target="#edit-customer<?php echo e($order->id); ?>" class="btn btn-primary"><i class="bi bi-pencil-square"></i></a>
                    <button type="button" name="delete" title="Delete" data-id="" class="delete btn btn-danger" data-bs-toggle="modal" data-bs-target="#delete-customer<?php echo e($order->id); ?>" title="Delete"><i class="bi bi-trash"></i></button>
                   </td>
                 </tr>

                   <!--Edit customer modal -->
                   <div class="modal right fade" id="edit-customer<?php echo e($order->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                    <div class="modal-dialog modal-md">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h4 class="modal-title" id="staticBackdropLabel">Edit Customer</h4>
                        </div>
                        <div class="modal-body">
                          <div class="row">
                              <div class="col-md-4">
                                <form class="row g-3" action="<?php echo e(route('orders.update', $order->id)); ?>" method="post" enctype="multipart/form-data">
                                  <?php echo csrf_field(); ?>
                                  <?php echo method_field('put'); ?>
                              </div>
                                  <div class="form-group">
                                    <label for="">Name</label>
                                    <input type="text" name="name" id="" value = "<?php echo e($order->name); ?>" class="form-control">
                                  </div>
                                  <div class="form-group">
                                    <label for="">Phone</label>
                                    <input type="text" name="phone_number" id="" value = "<?php echo e($order->phone_number); ?>"class="form-control">
                                  </div>
                                  <div class="form-group mb-2">
                                    <label for="">Address</label>
                                    <input type="text" name="address" id="" value = "<?php echo e($order->address); ?>" class="form-control">
                                  </div>
                              <div class="modal-footer">
                                <button type="submit" name="update" class="btn btn-secondary">Update</button>
                                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
                              </div>
                            </form>
                              </div>
                          </div>
                      </div>
                    </div>
                  </div>

                      <!--Delete user modal -->
                      <div class="modal right fade" id="delete-customer<?php echo e($order->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog modal-sm">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h4 class="modal-title" id="staticBackdropLabel">Delete Customer</h4>
                            </div>
                            <div class="modal-body">
                                    <form class="row g-3" action="<?php echo e(route('orders.destroy', $order->id)); ?>" method="post">
                                      <?php echo csrf_field(); ?>
                                      <?php echo method_field('delete'); ?>
                                      <p>Are you sure you want to delete <?php echo e($order->name); ?> ?</p>
                                  </div>
                                  <div class="modal-footer">
                                    <button type="submit" name="delete" class="btn btn-secondary">Delete</button>
                                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
                                  </div>
                                </form>
                                  </div>
                              </div>
                          </div>
                        </div>
                      </div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
             </table>
           </div>
         </div>
       </div>
    </div>
</main>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\POSSYSTEM\resources\views/customers/index.blade.php ENDPATH**/ ?>