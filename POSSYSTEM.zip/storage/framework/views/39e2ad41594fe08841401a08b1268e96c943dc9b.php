

<?php $__env->startSection('title','User Management'); ?>

<?php $__env->startSection('content'); ?>
<main>
    <div class="container-fluid px-4">
       <div class="row">
         <div class="col fw-bold fs-3 text-dark">
           User Management
           <hr class="dropdown-divider" style="height:3px;">
         </div>
       </div>
       <div class="row">
         <div class="card">
           <div class="card-header">
            <div class="d-grid gap-2 d-md-block float-end">
              <a href="" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#add-user"><i class="bi bi-person-plus"></i> Add User</a>
              <a href="" class="btn btn-primary "><i class="bi bi-printer"></i> Print</a>
            </div>
            </div>
           <div class="card-body">
             <table id="datatable" class="table table-bordered">
               <thead>
                 <tr>
                  <th>Name</th>
                  <th>Photo</th>
                  <th>Email</th>
                  <th>Phone</th>
                  <th>Address</th>
                  <th>Role</th>
                  <th>Action</th>
                 </tr>
               </thead>
               <tbody>
                 <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                   <td><?php echo e($user->name); ?></td>
                   <td class="text-center">
                     <img src="<?php echo e(asset('uploads/images/'.$user->image)); ?>" width='60px' height='60px' alt="Image" class="img img-responsive">
                    </td>
                   <td><?php echo e($user->email); ?></td>
                   <td><?php echo e($user->phone_number); ?></td>
                   <td><?php echo e($user->address); ?></td>
                   <td>
                     <?php if($user->role_as == 1): ?> Admin
                     <?php else: ?> Cashier
                     <?php endif; ?>
                   </td>
                   <td>
                    <button type="button" name="view"  id="" class="btn btn-success btn-xs" data-bs-toggle="modal" data-bs-target="#view-user<?php echo e($user->id); ?>"><i class="bi bi-eye"></i></button>
                    <a name="edit" href="" data-bs-toggle="modal" data-bs-target="#edit-user<?php echo e($user->id); ?>" class="btn btn-primary"><i class="bi bi-pencil-square"></i></a>
                    <button type="button" name="delete" title="Delete" data-id="" class="delete btn btn-danger" data-bs-toggle="modal" data-bs-target="#delete-user<?php echo e($user->id); ?>" title="Delete"><i class="bi bi-trash"></i></button>
                   </td>
                 </tr>
                 <!--Edit user modal -->
                  <div class="modal right fade" id="edit-user<?php echo e($user->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h4 class="modal-title" id="staticBackdropLabel">Edit User</h4>
                        </div>
                        <div class="modal-body">
                          <div class="row">
                              <div class="col-md-4 mt-4">
                                <form class="row g-3" action="<?php echo e(route('users.update', $user->id)); ?>" method="post" enctype="multipart/form-data">
                                  <?php echo csrf_field(); ?>
                                  <?php echo method_field('put'); ?>
                                <div class="text-center" style="border:1px dashed black; width: 240px; height: 240px;">
                                  <img src="<?php echo e(asset('uploads/images/'.$user->image)); ?>" width='240px' height='240px' alt="Image" class="img img-responsive">
                                </div>
                                <div class="form-group mt-3 mb-3">
                                  <input type="file" name="image" name="image" value="<?php echo e($user->image); ?>" class="form-control" id="inputGroupFile04" aria-describedby="inputGroupFileAddon04" aria-label="Upload">
                                </div>
                              </div>
                              <div class="col-md-8 ">
                                  <div class="form-group">
                                    <label for="">Name</label>
                                    <input type="text" name="name" id="" value = "<?php echo e($user->name); ?>" class="form-control">
                                  </div>
                                  <div class="form-group">
                                    <label for="">Email</label>
                                    <input type="email" name="email" id="" value = "<?php echo e($user->email); ?>" class="form-control">
                                  </div>
                                  <div class="form-group">
                                    <label for="">Phone</label>
                                    <input type="text" name="phone_number" id="" value = "<?php echo e($user->phone_number); ?>"class="form-control">
                                  </div>
                                  <div class="form-group">
                                    <label for="">Address</label>
                                    <input type="text" name="address" id="" value = "<?php echo e($user->address); ?>" class="form-control">
                                  </div>
                                  <div class="form-group ">
                                    <label for="">Password</label>
                                    <input type="password" name="password" id="" value = "<?php echo e($user->password); ?>" class="form-control">
                                  </div>
                                  <div class="form-group">
                                    <label for="">Confirm Password</label>
                                    <input type="password" name="confirm-password" value = "<?php echo e($user->password); ?>" id="" class="form-control">
                                  </div>
                                  <div class="form-group mb-3">
                                    <label for="">Role</label>
                                    <select name="role_as" id="" class="form-control form-select">
                                      <option value="1" <?php if($user->role_as == 1): ?>
                                        selected
                                      <?php endif; ?>>Admin</option>
                                      <option value="0" <?php if($user->role_as == 0): ?>
                                        selected
                                      <?php endif; ?>>Cashier</option>
                                    </select>
                                  </div>
                              </div>
                              <div class="modal-footer">
                                <button type="submit" name="update" class="btn btn-secondary">Update</button>
                                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
                              </div>
                            </form>
                              </div>
                          </div>
                      </div>
                    </div>
                  </div>

                   <!--Delete user modal -->
                   <div class="modal right fade" id="delete-user<?php echo e($user->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                    <div class="modal-dialog modal-sm">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h4 class="modal-title" id="staticBackdropLabel">Delete User</h4>
                        </div>
                        <div class="modal-body">
                                <form class="row g-3" action="<?php echo e(route('users.destroy', $user->id)); ?>" method="post">
                                  <?php echo csrf_field(); ?>
                                  <?php echo method_field('delete'); ?>
                                  <p>Are you sure you want to delete <?php echo e($user->name); ?> ?</p>
                              </div>
                              <div class="modal-footer">
                                <button type="submit" name="delete" class="btn btn-secondary">Delete</button>
                                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
                              </div>
                            </form>
                              </div>
                          </div>
                      </div>
                    </div>
                  </div>

                  <!--View user modal -->
                  <div class="modal right fade" id="view-user<?php echo e($user->id); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                    <div class="modal-dialog modal-lg">
                      <div class="modal-content">
                        <div class="modal-header float-center">
                          <h4 class="modal-title" id="staticBackdropLabel">View User</h4>
                          </div>
                        <div class="modal-body">
                          <div class="row">
                              <div class="col-md-4 mt-2 mb-3">
                                <div class="text-center" style="border:1px dashed black; width: 240px;height: 240px;">
                                  <img src="<?php echo e(asset('uploads/images/'.$user->image)); ?>" width='240px' height='240px' alt="Image" class="img img-responsive">
                                </div>
                              </div>
                              <div class="col-md-8 mt-3">
                                <form class="row g-3" action="<?php echo e(route('users.update', $user->id)); ?>" method="post">
                                  <?php echo csrf_field(); ?>
                                  <?php echo method_field('put'); ?>
                                  <div class="form-group">
                                    <label for="">Name</label>
                                    <input type="text" name="name" id="" value = "<?php echo e($user->name); ?>" class="form-control">
                                  </div>
                                  <div class="form-group">
                                    <label for="">Email</label>
                                    <input type="email" name="email" id="" value = "<?php echo e($user->email); ?>" class="form-control">
                                  </div>
                                  <div class="form-group">
                                    <label for="">Phone</label>
                                    <input type="text" name="phone_number" id="" value = "<?php echo e($user->phone_number); ?>"class="form-control">
                                  </div>
                                  <div class="form-group mb-3">
                                    <label for="">Address</label>
                                    <input type="text" name="address" id="" value = "<?php echo e($user->address); ?>" class="form-control">
                                  </div>
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
                              </div>
                            </form>
                              </div>
                          </div>
                      </div>
                    </div>
                  </div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
             </table>

           </div>
         </div>
       </div>
    </div>
</main>

    <!-- Add user modal -->
    <div class="modal right fade" id="add-user" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title" id="staticBackdropLabel">ADD USER</h4>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form class="row g-3" action="<?php echo e(route('users.store')); ?>" method="post" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <div class="form-group">
                <label for="">Name</label>
                <input type="text" name="name" id="" class="form-control">
              </div>
              <div class="form-group">
                <label for="">Email</label>
                <input type="email" name="email" id="" class="form-control">
              </div>
              <div class="form-group">
                <label for="">Phone</label>
                <input type="text" name="phone_number" id="" class="form-control">
              </div>
              <div class="form-group">
                <label for="">Address</label>
                <input type="text" name="address" id="" class="form-control">
              </div>
              <div class="form-group col-md-6">
                <label for="">Password</label>
                <input type="password" name="password" id="" class="form-control">
              </div>
              <div class="form-group col-md-6">
                <label for="">Confirm Password</label>
                <input type="password" name="confirm-password" id="" class="form-control">
              </div>
              <div class="form-group">
                <label for="">Role</label>
                <select name="role_as" id="" class="form-control form-select">
                  <option value="0">Cashier</option>
                  <option value="1">Admin</option>
                  <option value="2">Staff</option>
                </select>
              </div>
              <div class="form-group mt-3">
                <label for="">Upload User Profile</label>
                <input type="file" name="image" id="image" class="form-control" id="inputGroupFile04" aria-describedby="inputGroupFileAddon04" aria-label="Upload">
              </div>
          </div>
          <div class="modal-footer">
            <button type="submit" name="save" class="btn btn-secondary">Add</button>
            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button>
          </div>
        </form>
        </div>
      </div>
    </div>
    <!--End Add user modal -->

    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\POSSYSTEM\resources\views/users/index.blade.php ENDPATH**/ ?>