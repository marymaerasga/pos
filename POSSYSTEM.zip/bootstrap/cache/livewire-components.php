<?php return array (
  'order' => 'App\\Http\\Livewire\\Order',
);